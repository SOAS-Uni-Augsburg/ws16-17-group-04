package isse.control;

public enum ControlAction {
	INTERACTIVE_MODE,
	CPU_MODE,
	GAME_ENDED
}
