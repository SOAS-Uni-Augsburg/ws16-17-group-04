package isse.model;

public interface PlayStrategy {

	Move getMove(GameBoard board);

}
